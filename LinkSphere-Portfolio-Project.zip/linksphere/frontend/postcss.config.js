// Author: Nalini Jain
export default {plugins:{tailwindcss:{},autoprefixer:{}}};