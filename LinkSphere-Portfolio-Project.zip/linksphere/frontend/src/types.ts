// Author: Nalini Jain
export interface UrlResponse { alias:string; originalUrl:string; shortUrl:string; clickCount:number; createdAt:string; expiresAt:string|null }
export interface DailyMetric { date:string; clicks:number }
export interface AnalyticsResponse { alias:string; totalClicks:number; daily:DailyMetric[] }