/*
 * URL shortening form and QR preview. Author: Nalini Jain.
 */
import {FormEvent,useState} from 'react';
import {Link2,Sparkles,Copy,Download,QrCode} from 'lucide-react';
import {createShortUrl,getErrorMessage,qrCodeUrl} from '../services/api';
import type {UrlResponse} from '../types';
export default function UrlForm({onCreated}:{onCreated:(url:UrlResponse)=>void}){
 const [url,setUrl]=useState(''),[alias,setAlias]=useState(''),[result,setResult]=useState<UrlResponse|null>(null),[error,setError]=useState(''),[loading,setLoading]=useState(false);
 async function submit(e:FormEvent){e.preventDefault();setError('');setResult(null);setLoading(true);try{const created=await createShortUrl(url.trim(),alias.trim()||undefined);setResult(created);onCreated(created);}catch(err){setError(getErrorMessage(err));}finally{setLoading(false);}}
 async function copy(){if(result)await navigator.clipboard.writeText(result.shortUrl);}
 return <section className="panel p-6 sm:p-8">
  <div className="mb-6 flex items-center gap-3"><div className="icon-tile"><Link2 size={20}/></div><div><h2 className="text-lg font-semibold">Create a short link</h2><p className="text-sm text-slate-400">Turn long URLs into memorable, trackable links.</p></div></div>
  <form onSubmit={submit} className="space-y-4">
   <label className="block"><span className="field-label">Destination URL</span><input required type="url" pattern="https?://.+" placeholder="https://yourdomain.com/a/long/link" value={url} onChange={e=>setUrl(e.target.value)} className="field"/></label>
   <label className="block"><span className="field-label">Custom alias <span className="text-slate-500">(optional)</span></span><div className="flex items-center rounded-xl border border-white/10 bg-slate-950/60 focus-within:border-indigo-400"><span className="pl-3 text-sm text-slate-500">/api/</span><input value={alias} onChange={e=>setAlias(e.target.value)} minLength={3} maxLength={32} pattern="[a-zA-Z0-9_-]{3,32}" placeholder="launch-campaign" className="min-w-0 flex-1 bg-transparent px-2 py-3 text-sm outline-none"/></div><p className="mt-1 text-xs text-slate-500">3–32 letters, numbers, _ or -.</p></label>
   {error&&<p role="alert" className="rounded-lg border border-rose-400/20 bg-rose-400/10 p-3 text-sm text-rose-300">{error}</p>}
   <button disabled={loading} className="primary-button w-full"><Sparkles size={16}/>{loading?'Creating link…':'Create short link'}</button>
  </form>
  {result&&<div className="mt-6 rounded-2xl border border-indigo-400/20 bg-indigo-400/5 p-4"><p className="text-xs font-semibold uppercase tracking-wider text-indigo-300">Your link is ready</p><div className="mt-2 flex flex-wrap items-center gap-2"><a className="break-all text-lg font-semibold text-white" href={result.shortUrl} target="_blank" rel="noreferrer">{result.shortUrl}</a><button aria-label="Copy short URL" onClick={copy} className="icon-button"><Copy size={15}/></button></div><div className="mt-4 flex flex-col items-center gap-3 rounded-xl bg-white p-4 sm:flex-row"><img src={qrCodeUrl(result.alias)} alt={`QR code for ${result.shortUrl}`} className="h-32 w-32"/><div className="flex-1 text-center sm:text-left"><div className="flex items-center justify-center gap-2 text-sm font-semibold text-slate-900 sm:justify-start"><QrCode size={16}/> QR code</div><p className="mt-1 text-xs text-slate-500">Scan to open your destination.</p><a className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-indigo-700" href={qrCodeUrl(result.alias)} download={`linksphere-${result.alias}.png`}><Download size={14}/> Download PNG</a></div></div></div>}
 </section>;
}