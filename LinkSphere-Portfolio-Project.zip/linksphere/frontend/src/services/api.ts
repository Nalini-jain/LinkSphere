/*
 * Axios API client. Author: Nalini Jain.
 */
import axios from 'axios';
import type {AnalyticsResponse,UrlResponse} from '../types';
const api=axios.create({baseURL:import.meta.env.VITE_API_BASE_URL||'http://localhost:8080/api',timeout:12000,headers:{'Content-Type':'application/json'}});
export async function createShortUrl(originalUrl:string,customAlias?:string):Promise<UrlResponse>{
 const {data}=await api.post<UrlResponse>('/urls',{originalUrl,customAlias:customAlias||undefined}); return data;
}
export async function getAnalytics(alias:string,days=30):Promise<AnalyticsResponse>{
 const {data}=await api.get<AnalyticsResponse>(`/analytics/${encodeURIComponent(alias)}`,{params:{days}}); return data;
}
export function qrCodeUrl(alias:string):string {
 const base=import.meta.env.VITE_API_BASE_URL||'http://localhost:8080/api'; return `${base}/urls/${encodeURIComponent(alias)}/qr?size=420`;
}
export function getErrorMessage(error:unknown):string {
 if(axios.isAxiosError(error)) return error.response?.data?.detail||error.response?.data?.message||error.message;
 return 'Something went wrong. Please try again.';
}