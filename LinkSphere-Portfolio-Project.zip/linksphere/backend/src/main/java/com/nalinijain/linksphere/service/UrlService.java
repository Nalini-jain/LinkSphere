/*
 * URL creation and Redis cache-aside resolution. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.service;
import com.nalinijain.linksphere.dto.*;
import com.nalinijain.linksphere.model.UrlMapping;
import com.nalinijain.linksphere.repository.UrlMappingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.net.URI;
import java.security.SecureRandom;
import java.time.*;
@Service @RequiredArgsConstructor
public class UrlService {
 private static final String CHARS="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
 private static final SecureRandom RANDOM=new SecureRandom();
 private final UrlMappingRepository repository;
 private final StringRedisTemplate redis;
 @Value("${linksphere.public-base-url:http://localhost:8080}") private String publicBaseUrl;
 @Value("${linksphere.cache-ttl-seconds:86400}") private long cacheTtl;
 @Transactional
 public UrlResponse create(CreateUrlRequest request) {
  validateUrl(request.originalUrl());
  String alias=request.customAlias()==null||request.customAlias().isBlank()?generateAlias():request.customAlias();
  if(repository.existsByAlias(alias)) throw new ResponseStatusException(HttpStatus.CONFLICT,"Alias is already in use");
  UrlMapping mapping=UrlMapping.builder().alias(alias).originalUrl(request.originalUrl()).expiresAt(request.expiresAt()).build();
  try { mapping=repository.saveAndFlush(mapping); }
  catch(DataIntegrityViolationException ex){ throw new ResponseStatusException(HttpStatus.CONFLICT,"Alias is already in use"); }
  redis.opsForValue().set(key(alias),mapping.getOriginalUrl(),Duration.ofSeconds(cacheTtl));
  return response(mapping);
 }
 /** Redis is checked first; PostgreSQL supplies cache misses. Author: Nalini Jain. */
 @Transactional(readOnly=true)
 public String resolve(String alias) {
  String value=redis.opsForValue().get(key(alias));
  if(value!=null) return value;
  UrlMapping mapping=repository.findByAlias(alias).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Short link not found"));
  if(mapping.isExpired(Instant.now())) { redis.delete(key(alias)); throw new ResponseStatusException(HttpStatus.GONE,"Short link has expired"); }
  redis.opsForValue().set(key(alias),mapping.getOriginalUrl(),Duration.ofSeconds(cacheTtl));
  return mapping.getOriginalUrl();
 }
 @Transactional(readOnly=true)
 public UrlResponse get(String alias) {
  UrlMapping mapping=repository.findByAlias(alias).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Short link not found"));
  if(mapping.isExpired(Instant.now())) throw new ResponseStatusException(HttpStatus.GONE,"Short link has expired");
  return response(mapping);
 }
 private String generateAlias() {
  for(int attempt=0;attempt<12;attempt++){ StringBuilder b=new StringBuilder(7); for(int i=0;i<7;i++) b.append(CHARS.charAt(RANDOM.nextInt(CHARS.length()))); if(!repository.existsByAlias(b.toString())) return b.toString(); }
  throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Could not allocate a unique alias");
 }
 private void validateUrl(String value) {
  try { URI u=URI.create(value); if(u.getHost()==null||!("http".equalsIgnoreCase(u.getScheme())||"https".equalsIgnoreCase(u.getScheme()))) throw new IllegalArgumentException(); }
  catch(IllegalArgumentException ex){ throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"A valid absolute HTTP(S) URL is required"); }
 }
 private String key(String alias){ return "linksphere:url:"+alias; }
 private UrlResponse response(UrlMapping m){ return new UrlResponse(m.getAlias(),m.getOriginalUrl(),publicBaseUrl.replaceAll("/+$","")+"/api/"+m.getAlias(),m.getClickCount(),m.getCreatedAt(),m.getExpiresAt()); }
}