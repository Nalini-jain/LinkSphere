/* Author: Nalini Jain. */
package com.nalinijain.linksphere.dto;
import jakarta.validation.constraints.*;
import java.time.Instant;
public record CreateUrlRequest(
 @NotBlank @Size(max=2048) @Pattern(regexp="^https?://.+",message="URL must start with http:// or https://") String originalUrl,
 @Pattern(regexp="^[a-zA-Z0-9_-]{3,32}$",message="Alias must be 3-32 letters, numbers, _ or -") String customAlias,
 Instant expiresAt) {}