/* Author: Nalini Jain. */
package com.nalinijain.linksphere.repository;
import com.nalinijain.linksphere.model.ClickEvent;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.time.Instant;
import java.util.List;
public interface ClickEventRepository extends JpaRepository<ClickEvent,Long> {
 @Query(value="SELECT date_trunc('day', clicked_at) AS bucket, COUNT(*) AS clicks FROM click_events WHERE alias=:alias AND clicked_at>=:from AND clicked_at<:to GROUP BY bucket ORDER BY bucket", nativeQuery=true)
 List<Object[]> dailyClicks(@Param("alias") String alias,@Param("from") Instant from,@Param("to") Instant to);
 long countByAlias(String alias);
}