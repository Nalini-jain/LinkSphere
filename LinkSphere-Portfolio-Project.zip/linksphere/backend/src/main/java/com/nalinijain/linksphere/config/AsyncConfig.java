/* Author: Nalini Jain. */
package com.nalinijain.linksphere.config;
import org.springframework.context.annotation.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import java.util.concurrent.Executor;
@Configuration
public class AsyncConfig {
 @Bean(name="taskExecutor") public Executor taskExecutor(){
  ThreadPoolTaskExecutor executor=new ThreadPoolTaskExecutor(); executor.setCorePoolSize(4); executor.setMaxPoolSize(16); executor.setQueueCapacity(2000); executor.setThreadNamePrefix("linksphere-analytics-"); executor.initialize(); return executor;
 }
}