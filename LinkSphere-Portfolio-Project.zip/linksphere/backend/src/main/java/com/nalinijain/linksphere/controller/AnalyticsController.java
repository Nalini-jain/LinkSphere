/*
 * Analytics endpoint. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.controller;
import com.nalinijain.linksphere.dto.AnalyticsResponse;
import com.nalinijain.linksphere.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/analytics") @RequiredArgsConstructor
public class AnalyticsController {
 private final AnalyticsService analytics;
 @GetMapping("/{alias}") public AnalyticsResponse get(@PathVariable String alias,@RequestParam(defaultValue="30") int days){ return analytics.analytics(alias,days); }
}