/*
 * Click analytics event. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
@Entity @Table(name="click_events", indexes=@Index(name="idx_click_alias_time", columnList="alias, clicked_at"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ClickEvent {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false, length=32) private String alias;
 @Column(name="clicked_at", nullable=false, updatable=false) private Instant clickedAt;
 @Column(length=2048) private String referrer;
 @Column(name="user_agent", length=1024) private String userAgent;
 @PrePersist void onCreate(){ if(clickedAt==null) clickedAt=Instant.now(); }
}