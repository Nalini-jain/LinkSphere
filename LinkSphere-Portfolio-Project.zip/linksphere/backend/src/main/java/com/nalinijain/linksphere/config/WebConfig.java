/* Author: Nalini Jain. */
package com.nalinijain.linksphere.config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;
@Configuration
public class WebConfig implements WebMvcConfigurer {
 @Value("${linksphere.frontend-origin:http://localhost:5173}") private String frontendOrigin;
 @Override public void addCorsMappings(CorsRegistry registry){ registry.addMapping("/api/**").allowedOrigins(frontendOrigin).allowedMethods("GET","POST","OPTIONS").allowedHeaders("*").maxAge(3600); }
}