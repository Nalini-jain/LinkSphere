/*
 * URL management endpoints. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.controller;
import com.nalinijain.linksphere.dto.*;
import com.nalinijain.linksphere.service.UrlService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/urls") @RequiredArgsConstructor
public class UrlController {
 private final UrlService urls;
 /** Creates a short link. Author: Nalini Jain. */
 @PostMapping @ResponseStatus(HttpStatus.CREATED)
 public UrlResponse create(@Valid @RequestBody CreateUrlRequest request){ return urls.create(request); }
 @GetMapping("/{alias}") public UrlResponse get(@PathVariable String alias){ return urls.get(alias); }
}