/*
 * Persistent short URL model. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
@Entity @Table(name="url_mappings", indexes=@Index(name="idx_url_created_at", columnList="created_at"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UrlMapping {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false, unique=true, length=32) private String alias;
 @Column(name="original_url", nullable=false, length=2048) private String originalUrl;
 @Column(name="click_count", nullable=false) @Builder.Default private long clickCount=0;
 @Column(name="created_at", nullable=false, updatable=false) private Instant createdAt;
 @Column(name="expires_at") private Instant expiresAt;
 @PrePersist void onCreate(){ if(createdAt==null) createdAt=Instant.now(); }
 public boolean isExpired(Instant now){ return expiresAt!=null && !expiresAt.isAfter(now); }
}