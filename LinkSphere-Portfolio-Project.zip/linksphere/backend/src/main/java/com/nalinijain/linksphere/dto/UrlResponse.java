/* Author: Nalini Jain. */
package com.nalinijain.linksphere.dto;
import java.time.Instant;
public record UrlResponse(String alias,String originalUrl,String shortUrl,long clickCount,Instant createdAt,Instant expiresAt) {}