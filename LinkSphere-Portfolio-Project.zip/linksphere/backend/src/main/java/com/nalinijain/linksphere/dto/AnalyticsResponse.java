/* Author: Nalini Jain. */
package com.nalinijain.linksphere.dto;
import java.time.Instant;
import java.util.List;
public record AnalyticsResponse(String alias,long totalClicks,List<DailyMetric> daily) {
 public record DailyMetric(Instant date,long clicks) {}
}