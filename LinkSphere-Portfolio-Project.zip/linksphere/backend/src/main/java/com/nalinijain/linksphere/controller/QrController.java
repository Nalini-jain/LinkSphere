/*
 * QR code endpoint. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.controller;
import com.nalinijain.linksphere.dto.UrlResponse;
import com.nalinijain.linksphere.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/urls") @RequiredArgsConstructor
public class QrController {
 private final UrlService urls; private final QrCodeService qr;
 @GetMapping(value="/{alias}/qr",produces=MediaType.IMAGE_PNG_VALUE)
 public ResponseEntity<byte[]> getQr(@PathVariable String alias,@RequestParam(defaultValue="320") int size){
  UrlResponse mapping=urls.get(alias);
  return ResponseEntity.ok().cacheControl(CacheControl.maxAge(java.time.Duration.ofHours(12))).contentType(MediaType.IMAGE_PNG).body(qr.generate(mapping.shortUrl(),size));
 }
}