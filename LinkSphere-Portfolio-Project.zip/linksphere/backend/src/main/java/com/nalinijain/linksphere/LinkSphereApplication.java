/*
 * LinkSphere application. Author: Nalini Jain.
 */
package com.nalinijain.linksphere;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
@SpringBootApplication
@EnableAsync
public class LinkSphereApplication {
    /** Starts the LinkSphere API. Author: Nalini Jain. */
    public static void main(String[] args) { SpringApplication.run(LinkSphereApplication.class, args); }
}