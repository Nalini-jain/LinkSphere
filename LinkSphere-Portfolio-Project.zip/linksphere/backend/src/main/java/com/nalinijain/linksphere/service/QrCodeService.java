/*
 * QR PNG encoder. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.service;
import com.google.zxing.*;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import java.io.ByteArrayOutputStream;
import org.springframework.stereotype.Service;
@Service
public class QrCodeService {
 /** Encodes a URL as a PNG QR code. Author: Nalini Jain. */
 public byte[] generate(String value,int requestedSize) {
  try { int size=Math.max(128,Math.min(requestedSize,1024)); BitMatrix matrix=new QRCodeWriter().encode(value,BarcodeFormat.QR_CODE,size,size); ByteArrayOutputStream out=new ByteArrayOutputStream(); MatrixToImageWriter.writeToStream(matrix,"PNG",out); return out.toByteArray(); }
  catch(Exception ex){ throw new IllegalStateException("QR generation failed",ex); }
 }
}