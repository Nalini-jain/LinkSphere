/*
 * Asynchronous click event writer and analytics query service. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.service;
import com.nalinijain.linksphere.dto.AnalyticsResponse;
import com.nalinijain.linksphere.model.ClickEvent;
import com.nalinijain.linksphere.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.sql.Timestamp;
import java.time.*;
import java.util.*;
@Service @RequiredArgsConstructor
public class AnalyticsService {
 private final ClickEventRepository events;
 private final UrlMappingRepository urls;
 /** Writes click details away from the redirect request thread. Author: Nalini Jain. */
 @Async @Transactional
 public void recordClick(String alias,String referrer,String agent) {
  events.save(ClickEvent.builder().alias(alias).referrer(trim(referrer,2048)).userAgent(trim(agent,1024)).build());
 }
 @Transactional(readOnly=true)
 public AnalyticsResponse analytics(String alias,int days) {
  if(!urls.existsByAlias(alias)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Short link not found");
  int span=Math.max(1,Math.min(days,365)); Instant to=Instant.now(),from=to.minus(span,java.time.temporal.ChronoUnit.DAYS);
  Map<Instant,Long> result=new TreeMap<>();
  for(Object[] row:events.dailyClicks(alias,from,to)) result.put(((Timestamp)row[0]).toInstant(),((Number)row[1]).longValue());
  List<AnalyticsResponse.DailyMetric> daily=result.entrySet().stream().map(e->new AnalyticsResponse.DailyMetric(e.getKey(),e.getValue())).toList();
  return new AnalyticsResponse(alias,events.countByAlias(alias),daily);
 }
 private String trim(String s,int max){ return s==null?null:(s.length()<=max?s:s.substring(0,max)); }
}