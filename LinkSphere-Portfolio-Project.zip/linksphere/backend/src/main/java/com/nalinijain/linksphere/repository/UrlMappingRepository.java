/* Author: Nalini Jain. */
package com.nalinijain.linksphere.repository;
import com.nalinijain.linksphere.model.UrlMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface UrlMappingRepository extends JpaRepository<UrlMapping,Long> {
 Optional<UrlMapping> findByAlias(String alias);
 boolean existsByAlias(String alias);
}