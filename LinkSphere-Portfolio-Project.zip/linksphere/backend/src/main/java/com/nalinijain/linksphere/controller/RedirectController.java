/*
 * Alias redirection endpoint. Author: Nalini Jain.
 */
package com.nalinijain.linksphere.controller;
import com.nalinijain.linksphere.service.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api") @RequiredArgsConstructor
public class RedirectController {
 private final UrlService urls;
 private final AnalyticsService analytics;
 /** Redirects immediately and schedules analytics persistence asynchronously. Author: Nalini Jain. */
 @GetMapping("/{alias:[a-zA-Z0-9_-]{3,32}}")
 public ResponseEntity<Void> redirect(@PathVariable String alias,HttpServletRequest request){
  String target=urls.resolve(alias);
  analytics.recordClick(alias,request.getHeader("Referer"),request.getHeader("User-Agent"));
  return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION,target).build();
 }
}